
var elem = document.getElementById("videoOne");
if (elem.requestFullscreen) {
  $("video").attr("controls",true);
}